put files in dir:
%LOCALAPPDATA%\ItTakesTwo